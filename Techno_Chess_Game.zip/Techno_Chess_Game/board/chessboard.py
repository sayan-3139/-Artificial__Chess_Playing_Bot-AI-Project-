# board/chessboard.py
from board.tile import Tile
from pieces.nullpiece import nullpiece
from pieces.queen import queen
from pieces.pawn import pawn
from pieces.rook import rook
from pieces.bishop import bishop
from pieces.king import king
from pieces.knight import knight

class Board:
    def __init__(self):
        self.gameTiles = [[None for _ in range(8)] for _ in range(8)]
        self.create_board()

    def create_board(self):
        # Initialize all tiles with null pieces
        count = 0
        for row in range(8):
            for col in range(8):
                self.gameTiles[row][col] = Tile(count, nullpiece())
                count += 1

        # Place Black Pieces
        self.gameTiles[0][0] = Tile(0, rook("Black", 0))
        self.gameTiles[0][1] = Tile(1, knight("Black", 1))
        self.gameTiles[0][2] = Tile(2, bishop("Black", 2))
        self.gameTiles[0][3] = Tile(3, queen("Black", 3))
        self.gameTiles[0][4] = Tile(4, king("Black", 4))
        self.gameTiles[0][5] = Tile(5, bishop("Black", 5))
        self.gameTiles[0][6] = Tile(6, knight("Black", 6))
        self.gameTiles[0][7] = Tile(7, rook("Black", 7))
        for col in range(8):
            self.gameTiles[1][col] = Tile(8 + col, pawn("Black", 8 + col))

        # Place White Pieces
        self.gameTiles[7][0] = Tile(56, rook("White", 56))
        self.gameTiles[7][1] = Tile(57, knight("White", 57))
        self.gameTiles[7][2] = Tile(58, bishop("White", 58))
        self.gameTiles[7][3] = Tile(59, queen("White", 59))
        self.gameTiles[7][4] = Tile(60, king("White", 60))
        self.gameTiles[7][5] = Tile(61, bishop("White", 61))
        self.gameTiles[7][6] = Tile(62, knight("White", 62))
        self.gameTiles[7][7] = Tile(63, rook("White", 63))
        for col in range(8):
            self.gameTiles[6][col] = Tile(48 + col, pawn("White", 48 + col))

    def print_board(self):
        for row in self.gameTiles:
            print(" | ".join(tile.pieceOnTile.tostring() for tile in row))
            print("-" * 33)
