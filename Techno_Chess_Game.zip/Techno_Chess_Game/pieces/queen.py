class queen:
    def __init__(self, alliance, position):
        self.alliance = alliance
        self.position = position

    def tostring(self):
        return 'Q' if self.alliance == 'Black' else 'q'

    def legalmoveb(self, gametiles):
        # Queen = rook + bishop
        moves = []
        r, c = divmod(self.position, 8)
        directions = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
        for dr, dc in directions:
            nr, nc = r+dr, c+dc
            while 0 <= nr < 8 and 0 <= nc < 8:
                target = gametiles[nr][nc].pieceOnTile
                if target.tostring() == '-':
                    moves.append([nr, nc])
                else:
                    if target.alliance != self.alliance:
                        moves.append([nr, nc])
                    break
                nr += dr
                nc += dc
        return moves

    def legalmovew(self, gametiles):
        return self.legalmoveb(gametiles)
