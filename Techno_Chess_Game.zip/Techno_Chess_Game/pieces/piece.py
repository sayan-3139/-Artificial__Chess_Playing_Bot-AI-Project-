class piece:
    def __init__(self):
        pass
