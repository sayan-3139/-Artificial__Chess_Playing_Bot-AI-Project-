# player/AI.py
import copy
import random
from board.move import Move
from pieces.nullpiece import nullpiece
from pieces.queen import queen

class AI:
    PIECE_VALUES = {
        'P': 100, 'N': 320, 'B': 330, 'R': 500, 'Q': 900, 'K': 20000,
        'p': -100, 'n': -320, 'b': -330, 'r': -500, 'q': -900, 'k': -20000
    }

    def __init__(self, difficulty: int = 1):
        self.depth = difficulty  # lowest depth
        self._root_candidates = []

    def set_difficulty(self, depth: int):
        self.depth = depth

    # ---------------- Main entry ----------------
    def evaluate(self, gametiles, depth: int = None):
        if depth is None:
            depth = self.depth
        self._root_candidates = []

        try:
            _ = self._minimax(gametiles, depth, -10**12, 10**12, player_is_black=True, is_root=True)
        except Exception as e:
            print("AI.evaluate error in minimax:", e)
            return 0, 0, 0, 0

        if not self._root_candidates:
            return 0, 0, 0, 0

        chosen = random.choice(self._root_candidates)
        return chosen[0], chosen[1], chosen[2], chosen[3]

    # ---------------- Minimax with alpha-beta ----------------
    def _minimax(self, gametiles, depth, alpha, beta, player_is_black, is_root=False):
        if depth == 0:
            return self._evaluate_board(gametiles)

        movex = Move()
        moves = self._generate_all_moves(gametiles, for_black=player_is_black)

        if not moves:
            return self._evaluate_board(gametiles)

        if player_is_black:
            min_eval = 10**12
            for mv in moves:
                new_board = self._apply_move_copy(gametiles, mv)
                score = self._minimax(new_board, depth-1, alpha, beta, False)
                if is_root:
                    self._collect_root_candidate(mv, score)
                min_eval = min(min_eval, score)
                beta = min(beta, score)
                if beta <= alpha:
                    break
            return min_eval
        else:
            max_eval = -10**12
            for mv in moves:
                new_board = self._apply_move_copy(gametiles, mv)
                score = self._minimax(new_board, depth-1, alpha, beta, True)
                max_eval = max(max_eval, score)
                alpha = max(alpha, score)
                if beta <= alpha:
                    break
            return max_eval

    # ---------------- Generate legal moves ----------------
    def _generate_all_moves(self, gametiles, for_black: bool):
        movex = Move()
        moves = []

        for r in range(8):
            for c in range(8):
                piece = gametiles[r][c].pieceOnTile
                if piece.tostring() == "-":
                    continue
                if for_black and piece.alliance != "Black":
                    continue
                if not for_black and piece.alliance != "White":
                    continue

                # Generate moves safely
                try:
                    piece_moves = piece.legalmoveb(gametiles)
                except Exception:
                    piece_moves = []

                # Pinned filtering
                piece_moves = movex.pinned(gametiles, piece_moves, r, c, piece.alliance)

                # Castling
                try:
                    castle_moves = movex.castling(gametiles, piece.alliance)
                    if piece.tostring().upper() == 'K':
                        for mv in castle_moves:
                            if mv == 'ks':
                                target = [r, 6]
                                piece_moves.append(target)
                            elif mv == 'qs':
                                target = [r, 2]
                                piece_moves.append(target)
                except Exception:
                    pass

                # En-passant
                if piece.tostring() in ('P','p'):
                    try:
                        enp_moves = movex.enpassant(gametiles, r, c)
                        for em in enp_moves:
                            tr = r+1 if piece.tostring()=='P' else r-1
                            tc = c+1 if em[1]=='r' else c-1
                            if 0 <= tr < 8 and 0 <= tc < 8:
                                piece_moves.append([tr, tc])
                    except Exception:
                        pass

                # Collect all moves
                for tr, tc in piece_moves:
                    if 0 <= tr < 8 and 0 <= tc < 8:
                        moves.append((r, c, tr, tc))
        return moves

    # ---------------- Apply move ----------------
    def _apply_move_copy(self, gametiles, mv):
        sr, sc, dr, dc = mv
        new_board = copy.deepcopy(gametiles)
        src_piece = new_board[sr][sc].pieceOnTile
        new_board[dr][dc].pieceOnTile = src_piece
        new_board[sr][sc].pieceOnTile = nullpiece()
        src_piece.position = dr*8 + dc

        # Auto-promotion
        if src_piece.tostring() == 'P' and dr == 7:
            new_board[dr][dc].pieceOnTile = queen('White', dr*8+dc)
        if src_piece.tostring() == 'p' and dr == 0:
            new_board[dr][dc].pieceOnTile = queen('Black', dr*8+dc)

        return new_board

    # ---------------- Evaluate board ----------------
    def _evaluate_board(self, gametiles):
        score = 0
        white_moves = 0
        black_moves = 0
        movex = Move()

        for r in range(8):
            for c in range(8):
                piece = gametiles[r][c].pieceOnTile
                p = piece.tostring()
                score += self.PIECE_VALUES.get(p, 0)
                if p == "-":
                    continue
                try:
                    pm = piece.legalmoveb(gametiles)
                    pm = movex.pinned(gametiles, pm, r, c, piece.alliance)
                    if piece.alliance == 'White':
                        white_moves += len(pm)
                    else:
                        black_moves += len(pm)
                except Exception:
                    pass

        score += 5 * (white_moves - black_moves)
        return score

    # ---------------- Collect root moves ----------------
    def _collect_root_candidate(self, mv, score):
        if not self._root_candidates:
            self._root_candidates.append((mv[0], mv[1], mv[2], mv[3], score))
            return
        current_best = min(c[4] for c in self._root_candidates)
        if score < current_best:
            self._root_candidates = [(mv[0], mv[1], mv[2], mv[3], score)]
        elif score == current_best:
            self._root_candidates.append((mv[0], mv[1], mv[2], mv[3], score))
