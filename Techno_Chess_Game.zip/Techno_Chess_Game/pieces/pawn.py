class pawn:
    def __init__(self, alliance, position):
        self.alliance = alliance  # "White" or "Black"
        self.position = position
        self.moved = False
        self.enpassant = False

    def tostring(self):
        return 'P' if self.alliance == 'Black' else 'p'

    def legalmoveb(self, gametiles):
        moves = []
        r, c = divmod(self.position, 8)
        if self.alliance == 'Black':
            if r + 1 < 8 and gametiles[r+1][c].pieceOnTile.tostring() == '-':
                moves.append([r+1, c])
                if not self.moved and gametiles[r+2][c].pieceOnTile.tostring() == '-':
                    moves.append([r+2, c])
            # captures
            for dc in [-1, 1]:
                nc = c + dc
                if 0 <= nc < 8:
                    target = gametiles[r+1][nc].pieceOnTile
                    if target.tostring() != '-' and target.alliance == 'White':
                        moves.append([r+1, nc])
        else:  # White pawn
            if r - 1 >= 0 and gametiles[r-1][c].pieceOnTile.tostring() == '-':
                moves.append([r-1, c])
                if not self.moved and gametiles[r-2][c].pieceOnTile.tostring() == '-':
                    moves.append([r-2, c])
            for dc in [-1, 1]:
                nc = c + dc
                if 0 <= nc < 8:
                    target = gametiles[r-1][nc].pieceOnTile
                    if target.tostring() != '-' and target.alliance == 'Black':
                        moves.append([r-1, nc])
        return moves

    def legalmovew(self, gametiles):
        return self.legalmoveb(gametiles)
