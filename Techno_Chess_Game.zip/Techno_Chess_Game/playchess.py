# playchess.py
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import copy
import os
from board.chessboard import Board
from board.move import Move
from pieces.nullpiece import nullpiece
from pieces.queen import queen
from player.AI import AI

# --------- Config ----------
BOARD_SIZE = 8
SQUARE_SIZE = 100
CANVAS_SIZE = BOARD_SIZE * SQUARE_SIZE
LIGHT_COLOR = "#F0D9B5"
DARK_COLOR = "#B58863"
HIGHLIGHT_COLOR = "#FF6666"
ASSET_FOLDER = "./chessart"

# --------- Helper ----------
def update_position(row, col):
    return row * 8 + col

def load_image(filename, size=(SQUARE_SIZE, SQUARE_SIZE)):
    path = os.path.join(ASSET_FOLDER, filename)
    if not os.path.exists(path):
        return None
    try:
        img = Image.open(path).resize(size, Image.LANCZOS)
        return ImageTk.PhotoImage(img)
    except Exception:
        try:
            return tk.PhotoImage(file=path)
        except Exception:
            return None

# --------- Main App ----------
class ChessApp:
    def __init__(self, root, mode="ai"):
        self.root = root
        self.mode = mode
        self.root.title("PyChess")
        self.canvas = tk.Canvas(root, width=CANVAS_SIZE, height=CANVAS_SIZE)
        self.canvas.pack()

        # Game logic
        self.chessBoard = Board()
        self.movex = Move()
        self.ai = AI(difficulty=1)  # Lowest depth for responsiveness

        # UI state
        self.images = {}
        self.piece_items = {}
        self.selected = None
        self.legal_moves = []
        self.turn = 0  # 0: white, 1: black
        self.load_piece_images()
        self.draw_board()
        self.draw_pieces()
        self.canvas.bind("<Button-1>", self.on_click)

        # AI initial move if black
        if self.mode == "ai" and self.turn % 2 == 1:
            self.root.after(200, self.do_ai_move)

    # --------- Images ----------
    def load_piece_images(self):
        codes = {"K":"K", "Q":"Q", "R":"R", "B":"B", "N":"N", "P":"P"}
        for color in ("W","B"):
            for code in codes.values():
                fname = f"{color}{code}.png"
                img = load_image(fname)
                if img:
                    self.images[f"{color}{code}"] = img
        red = load_image("red_square.png")
        if red:
            self.images["red"] = red

    # --------- Draw Board & Pieces ----------
    def draw_board(self):
        self.canvas.delete("square")
        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE):
                color = LIGHT_COLOR if (r+c)%2==0 else DARK_COLOR
                x1, y1 = c*SQUARE_SIZE, r*SQUARE_SIZE
                x2, y2 = x1+SQUARE_SIZE, y1+SQUARE_SIZE
                self.canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="", tags="square")

    def draw_pieces(self):
        self.canvas.delete("piece")
        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE):
                piece = self.chessBoard.gameTiles[r][c].pieceOnTile
                if piece.tostring() == "-":
                    continue
                key = piece.alliance[0].upper() + piece.tostring().upper()
                img = self.images.get(key)
                x, y = c*SQUARE_SIZE + SQUARE_SIZE//2, r*SQUARE_SIZE + SQUARE_SIZE//2
                if img:
                    self.canvas.create_image(x, y, image=img, tags="piece")
                else:
                    self.canvas.create_text(x, y, text=key, font=("Arial", 20), tags="piece")

    # --------- Highlight ----------
    def highlight_moves(self):
        self.canvas.delete("highlight")
        for row, col in self.legal_moves:
            x, y = col*SQUARE_SIZE, row*SQUARE_SIZE
            self.canvas.create_rectangle(x, y, x+SQUARE_SIZE, y+SQUARE_SIZE,
                                         outline="red", width=3, tags="highlight")

    # --------- Click handler ----------
    def on_click(self, event):
        col, row = event.x // SQUARE_SIZE, event.y // SQUARE_SIZE
        if row < 0 or row >= 8 or col < 0 or col >= 8:
            return
        piece = self.chessBoard.gameTiles[row][col].pieceOnTile

        # Selecting a move
        if self.selected and (row, col) in self.legal_moves:
            self.make_move(self.selected[0], self.selected[1], row, col)
            self.selected, self.legal_moves = None, []
            self.draw_board()
            self.draw_pieces()
            if self.mode == "ai" and self.turn %2 == 1:
                self.root.after(100, self.do_ai_move)
            return

        # Selecting a piece
        if piece.tostring() == "-" or (self.turn%2==0 and piece.alliance=="Black") or \
           (self.turn%2==1 and self.mode=="ai" and piece.alliance=="White"):
            self.selected, self.legal_moves = None, []
            self.canvas.delete("highlight")
            return

        moves = piece.legalmoveb(self.chessBoard.gameTiles)
        moves = self.movex.pinned(self.chessBoard.gameTiles, moves, row, col, piece.alliance)
        self.selected = (row, col)
        self.legal_moves = [(m[0], m[1]) for m in moves]
        self.highlight_moves()

    # --------- Make Move ----------
    def make_move(self, src_row, src_col, dst_row, dst_col):
        piece = self.chessBoard.gameTiles[src_row][src_col].pieceOnTile
        if piece.tostring().upper() in ("K","R"):
            piece.moved = True

        self.chessBoard.gameTiles[dst_row][dst_col].pieceOnTile = piece
        self.chessBoard.gameTiles[src_row][src_col].pieceOnTile = nullpiece()
        piece.position = update_position(dst_row, dst_col)

        # Pawn promotion
        if piece.tostring() == "P" and dst_row == 7:
            self.chessBoard.gameTiles[dst_row][dst_col].pieceOnTile = queen("White", update_position(dst_row, dst_col))
        if piece.tostring() == "p" and dst_row == 0:
            self.chessBoard.gameTiles[dst_row][dst_col].pieceOnTile = queen("Black", update_position(dst_row, dst_col))

        self.turn += 1
        self.draw_board()
        self.draw_pieces()

    # --------- AI move ----------
    def do_ai_move(self):
        if self.mode != "ai" or self.turn %2 == 0:
            return
        sc = copy.deepcopy(self.chessBoard.gameTiles)
        try:
            sr, sc_, dr, dc = self.ai.evaluate(sc)
        except Exception as e:
            print("AI evaluate error:", e)
            return
        self.make_move(sr, sc_, dr, dc)

# --------- Launch ----------
def choose_mode_and_start():
    start_win = tk.Tk()
    start_win.title("PyChess - Choose Mode")
    start_win.geometry("400x200")

    def start_with(mode):
        start_win.destroy()
        app_root = tk.Tk()
        ChessApp(app_root, mode=mode)
        app_root.mainloop()

    tk.Label(start_win, text="Choose mode:", font=("Arial", 16)).pack(pady=10)
    tk.Button(start_win, text="Play vs AI (You play White)", width=25, command=lambda: start_with("ai")).pack(pady=8)
    tk.Button(start_win, text="2 Player (Local)", width=25, command=lambda: start_with("2player")).pack(pady=8)
    start_win.mainloop()

if __name__ == "__main__":
    choose_mode_and_start()
