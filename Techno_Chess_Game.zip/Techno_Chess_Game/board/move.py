# board/move.py
from pieces.nullpiece import nullpiece

class Move:
    def __init__(self):
        pass

    # ----------------- Check functions -----------------
    def checkb(self, gametiles):
        king_pos = None
        for i in range(8):
            for j in range(8):
                if gametiles[i][j].pieceOnTile.tostring() == 'K':
                    king_pos = (i, j)
                    break
        if not king_pos:
            return ["notchecked"]

        for i in range(8):
            for j in range(8):
                piece = gametiles[i][j].pieceOnTile
                if piece.alliance == 'White':
                    for move in piece.legalmoveb(gametiles):
                        if tuple(move) == king_pos:
                            return ["checked", [i, j]]
        return ["notchecked"]

    def checkw(self, gametiles):
        king_pos = None
        for i in range(8):
            for j in range(8):
                if gametiles[i][j].pieceOnTile.tostring() == 'k':
                    king_pos = (i, j)
                    break
        if not king_pos:
            return ["notchecked"]

        for i in range(8):
            for j in range(8):
                piece = gametiles[i][j].pieceOnTile
                if piece.alliance == 'Black':
                    for move in piece.legalmoveb(gametiles):
                        if tuple(move) == king_pos:
                            return ["checked", [i, j]]
        return ["notchecked"]

    # ----------------- Move conversion -----------------
    @staticmethod
    def update_position(x, y):
        return x * 8 + y

    # ----------------- Moves if checked -----------------
    def moves_if_checked(self, gametiles, alliance):
        movi = []
        for i in range(8):
            for j in range(8):
                piece = gametiles[i][j].pieceOnTile
                if piece.alliance != alliance:
                    continue
                for move in piece.legalmoveb(gametiles):
                    x, y = move
                    captured_piece = gametiles[x][y].pieceOnTile
                    gametiles[x][y].pieceOnTile = piece
                    gametiles[i][j].pieceOnTile = nullpiece()
                    piece.position = self.update_position(x, y)

                    check_result = self.checkb(gametiles) if alliance == 'Black' else self.checkw(gametiles)
                    if check_result[0] == 'notchecked':
                        movi.append([i, j, x, y])

                    gametiles[i][j].pieceOnTile = piece
                    gametiles[x][y].pieceOnTile = captured_piece
                    piece.position = self.update_position(i, j)
        return movi

    # ----------------- Castling -----------------
    def castling(self, gametiles, alliance):
        castling_moves = []
        king_char = 'K' if alliance == 'Black' else 'k'
        rook_char = 'R' if alliance == 'Black' else 'r'

        for i in range(8):
            for j in range(8):
                tile_piece = gametiles[i][j].pieceOnTile
                if tile_piece.tostring() == king_char and not tile_piece.moved:
                    # Kingside
                    if j + 3 < 8 and gametiles[i][j+3].pieceOnTile.tostring() == rook_char and not gametiles[i][j+3].pieceOnTile.moved:
                        if all(gametiles[i][j+k].pieceOnTile.tostring() == '-' for k in [1,2]):
                            castling_moves.append('ks')
                    # Queenside
                    if gametiles[i][0].pieceOnTile.tostring() == rook_char and not gametiles[i][0].pieceOnTile.moved:
                        if all(gametiles[i][k].pieceOnTile.tostring() == '-' for k in [1,2,3]):
                            castling_moves.append('qs')
                    return castling_moves
        return castling_moves

    # ----------------- En Passant -----------------
    def enpassant(self, gametiles, y, x):
        piece = gametiles[y][x].pieceOnTile
        moves = []

        if piece.tostring() == 'P' and y == 4:
            for dx, target_char in [(-1, 'p'), (1, 'p')]:
                nx = x + dx
                if 0 <= nx < 8:
                    target = gametiles[y][nx].pieceOnTile
                    if target.tostring() == target_char and target.enpassant:
                        moves.append([[y, x], 'l' if dx == -1 else 'r'])
        elif piece.tostring() == 'p' and y == 3:
            for dx, target_char in [(-1, 'P'), (1, 'P')]:
                nx = x + dx
                if 0 <= nx < 8:
                    target = gametiles[y][nx].pieceOnTile
                    if target.tostring() == target_char and target.enpassant:
                        moves.append([[y, x], 'l' if dx == -1 else 'r'])
        return moves

    # ----------------- Pinned pieces -----------------
    def pinned(self, gametiles, moves, y, x, alliance):
        safe_moves = []
        for move in moves:
            m, k = move
            captured_piece = gametiles[m][k].pieceOnTile
            gametiles[m][k].pieceOnTile = gametiles[y][x].pieceOnTile
            gametiles[y][x].pieceOnTile = nullpiece()

            check_result = self.checkb(gametiles) if alliance == 'Black' else self.checkw(gametiles)
            if check_result[0] == 'notchecked':
                safe_moves.append(move)

            gametiles[y][x].pieceOnTile = gametiles[m][k].pieceOnTile
            gametiles[m][k].pieceOnTile = captured_piece

        return safe_moves
