class knight:
    def __init__(self, alliance, position):
        self.alliance = alliance
        self.position = position

    def tostring(self):
        return 'N' if self.alliance == 'Black' else 'n'

    def legalmoveb(self, gametiles):
        moves = []
        r, c = divmod(self.position, 8)
        jumps = [(2,1),(1,2),(-1,2),(-2,1),(-2,-1),(-1,-2),(1,-2),(2,-1)]
        for dr, dc in jumps:
            nr, nc = r+dr, c+dc
            if 0 <= nr < 8 and 0 <= nc < 8:
                target = gametiles[nr][nc].pieceOnTile
                if target.tostring() == '-' or target.alliance != self.alliance:
                    moves.append([nr, nc])
        return moves

    def legalmovew(self, gametiles):
        return self.legalmoveb(gametiles)
