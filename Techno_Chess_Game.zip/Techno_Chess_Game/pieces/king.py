class king:
    def __init__(self, alliance, position):
        self.alliance = alliance
        self.position = position
        self.moved = False

    def tostring(self):
        return 'K' if self.alliance == 'Black' else 'k'

    def legalmoveb(self, gametiles):
        moves = []
        r, c = divmod(self.position, 8)
        directions = [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
        for dr, dc in directions:
            nr, nc = r+dr, c+dc
            if 0 <= nr < 8 and 0 <= nc < 8:
                target = gametiles[nr][nc].pieceOnTile
                if target.tostring() == '-' or target.alliance != self.alliance:
                    moves.append([nr, nc])
        return moves

    def legalmovew(self, gametiles):
        return self.legalmoveb(gametiles)
