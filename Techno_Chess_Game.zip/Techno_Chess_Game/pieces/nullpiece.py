class nullpiece:
    def __init__(self):
        self.alliance = None
        self.moved = False
        self.position = -1

    def tostring(self):
        return "-"
    
    def legalmoveb(self, gametiles):
        return []

    def legalmovew(self, gametiles):
        return []
