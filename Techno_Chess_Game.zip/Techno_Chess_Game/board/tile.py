# board/tile.py
class Tile:
    def __init__(self, coordinate, piece):
        self.tileCoordinate = coordinate  # position on board 0-63
        self.pieceOnTile = piece          # piece currently on this tile

    def __str__(self):
        return str(self.pieceOnTile.tostring())
